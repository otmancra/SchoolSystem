CREATE PROCEDURE check_version AS
BEGIN
 -- some code which performs transaction processing ...
$if DBMS_DB_VERSION.VER_LE_10_2 $then

-- traditional commit
COMMIT;
DBMS_OUTPUT.PUT_LINE ('The transaction has been successfully committed.');
$else
-- faster COMMIT supported in 10.2
COMMIT WRITE IMMEDIATE NOWAIT;
DBMS_OUTPUT.PUT_LINE ('The transaction has been successfully committed.');
$end
END;
/
