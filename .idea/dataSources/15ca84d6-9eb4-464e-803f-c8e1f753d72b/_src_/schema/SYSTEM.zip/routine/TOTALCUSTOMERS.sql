CREATE function totalcustomers
return number
is
total number(2):=0;
begin
select count(*) into total
from customers;
return total;
end;
/
