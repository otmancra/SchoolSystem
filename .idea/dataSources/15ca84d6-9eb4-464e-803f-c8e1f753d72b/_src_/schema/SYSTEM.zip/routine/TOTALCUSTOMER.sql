CREATE function totalcustomer
/
